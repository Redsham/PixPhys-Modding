﻿using UnityEngine;

public class TemplateMod : MonoBehaviour
{
    public static void Main()
    {
    }
}
